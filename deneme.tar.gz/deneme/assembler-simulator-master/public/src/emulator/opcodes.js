app.service('opcodes', [function() {
    var opcodes = {
	ADD: 0,
	ADDi: 1,
	NAND: 2,
	NANDi: 3,
	SRL: 4,
	SRLi: 5,
	LT: 6,
	LTi: 7,
	MUL: 14,
	MULi: 15,
	CP: 8,
	CPi: 9,
	CPI: 10,
	CPIi: 11,
	BZJ: 12,
	BZJi: 13
	
    };

    return opcodes;
}]);
