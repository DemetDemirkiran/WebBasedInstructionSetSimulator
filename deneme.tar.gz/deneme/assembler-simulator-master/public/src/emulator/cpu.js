app.service('cpu', ['opcodes', 'memory', function(opcodes, memory) {
    var cpu = {
        step: function() {
            var self = this;

            if (self.fault === true) {
                throw "FAULT. Reset to continue.";
            }

            try {
                var checkGPR = function(reg) {
                    if (reg < 0 || reg >= self.gpr.length) {
                        throw "Invalid register: " + reg;
                    } else {
                        return reg;
                    }
                };

                var checkGPR_SP = function(reg) {
                    if (reg < 0 || reg >= 1 + self.gpr.length) {
                        throw "Invalid register: " + reg;
                    } else {
                        return reg;
                    }
                };

                var setGPR_SP = function(reg,value)
                {
                    if(reg >= 0 && reg < self.gpr.length) {
                        self.gpr[reg] = value;
                    } else if(reg == self.gpr.length) {
                        self.sp = value;

                        // Not likely to happen, since we always get here after checkOpertion().
                        if (self.sp < self.minSP) {
                            throw "Stack overflow";
                        } else if (self.sp > self.maxSP) {
                            throw "Stack underflow";
                        }
                    } else {
                        throw "Invalid register: " + reg;
                    }
                };

                var getGPR_SP = function(reg)
                {
                    if(reg >= 0 && reg < self.gpr.length) {
                        return self.gpr[reg];
                    } else if(reg == self.gpr.length) {
                        return self.sp;
                    } else {
                        throw "Invalid register: " + reg;
                    }
                };

                var indirectRegisterAddress = function(value) {
                    var reg = value % 8;
                    
                    var base;
                    if (reg < self.gpr.length) {
                        base = self.gpr[reg];
                    } else {
                        base = self.sp;
                    }
                    
                    var offset = Math.floor(value / 8);
                    if ( offset > 15 ) {
                        offset = offset - 32;
                    }
                    
                    return base+offset;
                };

                var checkOperation = function(value) {
                    self.zero = false;
                    self.carry = false;

                    if (value >= 256) {
                        self.carry = true;
                        value = value % 256;
                    } else if (value === 0) {
                        self.zero = true;
                    } else if (value < 0) {
                        self.carry = true;
                        value = 256 - (-value) % 256;
                    }

                    return value;
                };

                var jump = function(newIP) {
                    if (newIP < 0 || newIP >= memory.data.length) {
                        throw "IP outside memory";
                    } else {
                        self.ip = newIP;
                    }
                };

                var push = function(value) {
                    memory.store(self.sp--, value);
                    if (self.sp < self.minSP) {
                        throw "Stack overflow";
                    }
                };

                var pop = function() {
                    var value = memory.load(++self.sp);
                    if (self.sp > self.maxSP) {
                        throw "Stack underflow";
                    }

                    return value;
                };

                var division = function(divisor) {
                    if (divisor === 0) {
                        throw "Division by 0";
                    }

                    return Math.floor(self.gpr[0] / divisor);
                };

                if (self.ip < 0 || self.ip >= memory.data.length) {
                    throw "Instruction pointer is outside of memory";
                }
                
                var regTo, regFrom, memFrom, memTo, number;
                
                var instr_1, instr_2;
                var temp_1,temp_2, temp_3;
		var byte_1 = memory.load(self.ip);
		var byte_2 = memory.load(self.ip+1);
		var byte_3 = memory.load(self.ip+2);
		var byte_4 = memory.load(self.ip+3);
		
		// var instr = memory.load(self.ip);
		var instr = byte_1 & 0xF0;
		instr = instr >> 4;
		var operand_1 = byte_1 & 0xF;
		operand_1 = operand_1 << 8;
		operand_1 = operand_1 | byte_2;
		operand_1 = operand_1 << 2;
		operand_1 = operand_1 | (byte_3 >> 6);
		var operand_2 = byte_3 & 0x3F;
		operand_2 = operand_2 << 8;
		operand_2 = operand_2 | byte_4;
    
                switch(instr) {
                     case opcodes.NONE:
                        return false; // Abort step
                     case opcodes.ADD:
                          temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                          temp_2 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                          temp_1 = (temp_1 + temp_2) & 0xFFFFFFFF;
                          memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                          memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                          memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                          memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                          self.ip = self.ip + 4;
                     break;

                     case opcodes.ADDi:
                         temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                         temp_1 = (temp_1 + operand_2) & 0xFFFFFFFF;
                         memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                         memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                         memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                         memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                         self.ip = self.ip + 4;
                     break;

                     case opcodes.NAND:
                        temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                        temp_2 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                         temp_3 = ~(temp_1 & temp_2);
                        memory.store( operand_1*4, ((temp_3 & 0xFF000000) >> 24) );
                        memory.store( operand_1*4+1, ((temp_3 & 0x00FF0000) >> 16) );
                        memory.store( operand_1*4+2, ((temp_3 & 0x0000FF00) >> 8) );
                        memory.store( operand_1*4+3, ((temp_3 & 0x000000FF) ) );
                        self.ip = self.ip + 4;
                     break;

                     case opcodes.NANDi:
                        temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                        temp_3 = ~(temp_1 & operand_2);
                        memory.store( operand_1*4, ((temp_3 & 0xFF000000) >> 24) );
                        memory.store( operand_1*4+1, ((temp_3 & 0x00FF0000) >> 16) );
                        memory.store( operand_1*4+2, ((temp_3 & 0x0000FF00) >> 8) );
                        memory.store( operand_1*4+3, ((temp_3 & 0x000000FF) ) );
                        self.ip = self.ip + 4;
                     break;

                     case opcodes.SRL:
                        temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                        temp_2 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                        if(temp_2 < 32){
                                temp_1 = temp_1 >> temp_2;
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        } else {
                                temp_1 = temp_1 << (temp_2 - 32);
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        }
                        self.ip = self.ip + 4;
                     break;

                     case opcodes.SRLi:
                        temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);

                        if(operand_2 < 32){
                                temp_1 = temp_1 >> operand_2;
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        } else {
                                temp_1 = temp_1 << (operand_2 - 32);
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        }
                        self.ip = self.ip + 4;
                     break;

                     case opcodes.LT:
                         temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                         temp_2 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                        if(temp_1 < temp_2){
                                temp_1 = 1;
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        } else {
                                temp_1 = 0;
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        }
                        self.ip = self.ip + 4;
                      break;

                      case opcodes.LTi:
                         temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                      
                        if(temp_1 < operand_2){
                                temp_1 = 1;
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        } else {
                                temp_1 = 0;
                                memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                                memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                                memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                                memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        }
                        self.ip = self.ip + 4;
                       break;

                       case opcodes.MUL:
                          temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                          temp_2 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                          temp_1 = (temp_1 * temp_2) & 0xFFFFFFFF;
                          memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                          memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                          memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                          memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                          self.ip = self.ip + 4;
                       break;

                      case opcodes.MULi:
                         temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                         temp_1 = (temp_1 * operand_2) & 0xFFFFFFFF;
                         memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                         memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                         memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                         memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                         self.ip = self.ip + 4;
                      break;

                      case opcodes.CP:
                        temp_1 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                        memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                        memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                        memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                        memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        self.ip = self.ip + 4;
                      break;

                      case opcodes.CPi:
                        memory.store(operand_1*4, ((operand_2 & 0xFF000000) >> 24));
                        memory.store(operand_1*4+1, ((operand_2 & 0x00FF0000) >> 16));
                        memory.store(operand_1*4+2, ((operand_2 & 0x0000FF00) >> 8));
                        memory.store(operand_1*4+3, ((operand_2 & 0x000000FF)));
                        self.ip = self.ip + 4;
                      break;

                      case opcodes.CPI:
                        temp_1 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                        temp_1 = (memory.load(temp_1*4) << 24) | (memory.load(temp_1*4+1) << 16) | (memory.load(temp_1*4+2) << 8) | memory.load(temp_1*4+3);
                        memory.store(operand_1*4, ((temp_1 & 0xFF000000) >> 24));
                        memory.store(operand_1*4+1, ((temp_1 & 0x00FF0000) >> 16));
                        memory.store(operand_1*4+2, ((temp_1 & 0x0000FF00) >> 8));
                        memory.store(operand_1*4+3, ((temp_1 & 0x000000FF)));
                        self.ip = self.ip + 4;
                      break;

                      case opcodes.CPIi:
                         temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                         temp_2 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                         memory.store(temp_1*4, ((temp_2 & 0xFF000000) >> 24));
                         memory.store(temp_1*4+1, ((temp_2 & 0x00FF0000) >> 16));
                         memory.store(temp_1*4+2, ((temp_2 & 0x0000FF00) >> 8));
                         memory.store(temp_1*4+3, ((temp_2 & 0x000000FF)));
                         self.ip = self.ip + 4;
                      break;

                      case opcodes.BZJ:
                        temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                        temp_2 = (memory.load(operand_2*4) << 24) | (memory.load(operand_2*4+1) << 16) | (memory.load(operand_2*4+2) << 8) | memory.load(operand_2*4+3);
                        if(temp_2 === 0){
                                self.ip = temp_1 * 4;
                        } else {
                                self.ip = self.ip + 4;
                        }
                      break;

                      case opcodes.BZJi:
                        temp_1 = (memory.load(operand_1*4) << 24) | (memory.load(operand_1*4+1) << 16) | (memory.load(operand_1*4+2) << 8) | memory.load(operand_1*4+3);
                        self.ip = (temp_1 + operand_2)*4;
                      break;

                    default:
                        throw "Invalid op code: " + instr;
                }
		self.sp = memory.load( 1*4 + 3);
                self.zero = memory.load( 2*4 +3);

                self.carry = memory.load( 11*4 +3);

                self.sm = memory.load( 11*4 +3);
                self.sm_1 = memory.load( 12*4 + 3);
                self.sm_2 = memory.load( 13*4 +3);
                self.sm_3 = memory.load( 14*4 +3);
                self.sm_4 = memory.load( 15*4 + 3);
                self.sm_5 = memory.load( 16*4 +3);
                return true;
            } catch(e) {
                self.fault = true;
                throw e;
            }
        },
        reset: function() {
            var self = this;
            self.maxSP = 231;
            self.minSP = 0;

            self.gpr = [0, 0, 0, 0];
            self.sp = 0;
            self.ip = 0;
           // self.bs = 0;
            self.zero = 0;
            self.carry = 0;
            self.sm = 0;
            self.sm_1 = 0;
            self.sm_2 = 0;
            self.sm_3 = 0;
            self.sm_4 = 0;
            self.sm_5 = 0;
            self.fault = false;
        }
    };

    cpu.reset();
    return cpu;
}]);

