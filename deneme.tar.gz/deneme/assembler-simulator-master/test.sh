#!/bin/sh

./vscompiler file.c | sed '/^[[:blank:]]*\/\//d;s/\/\/.*//' | sed '/^\s*$/d' # cleanse compiler output to get pure assembly code
