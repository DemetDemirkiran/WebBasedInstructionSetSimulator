// to-do #1: limit POST size (see: https://stackoverflow.com/a/8640308/1869172)

// this line allows us to use the expressjs module
var express = require('express');

// this line allows us to use fs module
const fs = require('fs');

// Add this line so we can serve files from our local
// directory
var path = require('path');
var app = express();

// Add the abillity to serve our static files from the public directory
app.use(express.static('public'));

// Here we serve up our index page
app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/public/index.html'));
});

var server = app.listen(3000, function () {
    var host = server.address().address;
    var port = server.address().port;
    
    console.log("Server listening at http://%s:%s", host, port); 
});

const { spawn } = require('child_process');

var bodyParser = require('body-parser')

/** bodyParser.urlencoded(options)
 * Parses the text as URL encoded data (which is how browsers tend to send form data from regular forms set to POST)
 * and exposes the resulting object (containing the keys and values) on req.body
 */
app.use(bodyParser.urlencoded({
    extended: true
}));

/**bodyParser.json(options)
 * Parses the text as JSON and exposes the resulting object on req.body.
 */
app.use(bodyParser.json());

app.post('/', function(req, res) {
    
    let results = [];
    console.log("request is received");
    let incoming_data = req.body.cCode;
    // write to a new file named file.c
    fs.writeFile('file.c', incoming_data, (err) => {
	// throws an error, you could also catch it here
	if (err) throw err;
	
	// success case, the file was saved
	console.log('data saved!');
    });
    console.log(`${incoming_data}`);
     const ps = spawn('sh', ['test.sh']);
   // const ps = spawn('./vscompiler', ['file.c']);
    ps.stdout.on('data', (data) => {
	console.log(data.toString());
	results.push(`${data}`);
    });

    ps.stderr.on('data', (data) => {
	// throw any error
	console.log(`stderr: ${data}`);
    });

    ps.on('close', (code) => {
	console.log(`child process exited with code ${code}`);
	console.log(`results`);
	res.status(200).json({ assemblyCode: results});
	const ps_rm = spawn('rm', ['file.c']);
    });

    
    
});
