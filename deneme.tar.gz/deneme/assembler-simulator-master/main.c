int main() {
  return 30+12;
}
